var searchData=
[
  ['currentfreqchannelindex_0',['CurrentFreqChannelIndex',['../class_c_s_library_1_1_high_level_interface.html#a382abde315dc0d6b72bd6d24df7bfb9e',1,'CSLibrary::HighLevelInterface']]],
  ['currentinterfacetype_1',['CurrentInterfaceType',['../class_c_s_library_1_1_high_level_interface.html#a1a8b0f17cba7ee11343a3ec3e37b0e1f',1,'CSLibrary::HighLevelInterface']]]
];
