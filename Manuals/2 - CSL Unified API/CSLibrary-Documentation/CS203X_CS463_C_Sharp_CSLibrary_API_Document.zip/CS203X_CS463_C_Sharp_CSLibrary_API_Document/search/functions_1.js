var searchData=
[
  ['disconnect_0',['Disconnect',['../class_c_s_library_1_1_high_level_interface.html#a3a566ab2a70b6d8492a81f8fa6fc4d10',1,'CSLibrary::HighLevelInterface']]],
  ['dispose_1',['Dispose',['../class_c_s_library_1_1_high_level_interface.html#a9b1d0d2c17257136194512e2505bab9e',1,'CSLibrary::HighLevelInterface']]]
];
