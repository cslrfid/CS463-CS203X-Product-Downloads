var searchData=
[
  ['state_0',['state',['../class_c_s_library_1_1_events_1_1_on_state_changed_event_args.html#a52d657c7bf666d584dd363b3e92899f5',1,'CSLibrary::Events::OnStateChangedEventArgs']]],
  ['success_1',['success',['../class_c_s_library_1_1_events_1_1_on_access_completed_event_args.html#a2b7b1074a71b545c9f38626e398f63b4',1,'CSLibrary::Events::OnAccessCompletedEventArgs']]]
];
